IF EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE name = 'PlanitFitDB')
BEGIN
	DROP DATABASE PlanitFitDB
	print '' print '*** dropping database PlanitFitDB ***'
END
GO

CREATE DATABASE PlanitFitDB
GO

print '' print '*** using database PlanitFitDB ***' 
GO
USE [PlanitFitDB]
GO

print '' print '*** Creating Musclegroup Table ***'
GO
/* ***Object: Table[dbo].[MuscleGroup]*** */
CREATE TABLE [dbo].[MuscleGroup](
	[MuscleGroupID]		[int]IDENTITY(100000,1)	NOT NULL,
	[MuscleGroupName]	[varchar](50)			NOT NULL
	CONSTRAINT [pk_MuscleGroupID] PRIMARY KEY ([MuscleGroupID] ASC)
)
GO
print '' print '*** Inserting MuscleGroup Sample Records ***'
GO
INSERT INTO [dbo].[MuscleGroup]
		([MuscleGroupName])
	VALUES
		('Chest'),
		('Back'),
		('Biceps'),
		('Triceps'),
		('Shoulders'),
		('Legs'),
		('Abs')
GO

print '' print '*** Creating Exercise Table ***'
GO
/* ***Object: Table[dbo].[Exercise]*** */
CREATE TABLE [dbo].[Exercise](
	[ExerciseID]	[int]IDENTITY(100000,1) NOT NULL,
	[ExerciseName] 	[varchar](50)		NOT NULL,
	[MuscleGroupID]	[int]				
	CONSTRAINT [pk_ExerciseID] PRIMARY KEY ([ExerciseID] ASC)
)
GO
print '' print '*** Inserting Exercise Sample Records ***'
GO
INSERT INTO [dbo].[Exercise]
		([ExerciseName], [MuscleGroupID])
	VALUES
		('Dumbbell Bench Press', 100000),
		('Deadlift', 100001),
		('Rest', NULL)
GO

print '' print '*** Creating WorkoutOfTheDay Table ***'
GO
/* ***Object: Table[dbo].[WorkoutOfTheDay]*** */
CREATE TABLE [dbo].[WorkoutOfTheDay](
	[DaysWorkoutID]	[int]IDENTITY(100000,1) NOT NULL,
	[DayNumber] 	[int]				NOT NULL
	CONSTRAINT [pk_DaysWorkoutID] PRIMARY KEY ([DaysWorkoutID] ASC)
)
GO
print '' print '*** Inserting WorkoutOfTheDay Sample Records ***'
GO
INSERT INTO [dbo].[WorkoutOfTheDay]
		([DayNumber])
	VALUES
		(1),
		(2)
GO

print '' print '*** Creating WorkoutSplit Table ***'
GO
/* ***Object: Table[dbo].[WorkoutSplit]*** */
CREATE TABLE [dbo].[WorkoutSplit](
	[SplitID]		[int]IDENTITY(100000,1) NOT NULL,
	[SplitName] 	[varchar](50)				NOT NULL
	CONSTRAINT [pk_SplitID] PRIMARY KEY ([SplitID] ASC)
)
GO
print '' print '*** Inserting WorkoutSplit Sample Records ***'
GO
INSERT INTO [dbo].[WorkoutSplit]
		([SplitName])
	VALUES
		("3-day"),
		("4-day"),
		("5-day"),
		("6-day")
GO

print '' print '*** Creating WorkoutProgram Table ***'
GO
/* ***Object: Table[dbo].[WorkoutProgram]*** */

CREATE TABLE [dbo].[WorkoutProgram](
	[ProgramID]			[int]IDENTITY(100000,1)	NOT NULL,
	[Duration]			[varchar](50)			NOT NULL,
	[SplitID]			[int]					NOT NULL	
	CONSTRAINT [pk_ProgramID] PRIMARY KEY ([ProgramID] ASC)
)
GO
print '' print '*** Inserting WorkoutProgram Sample Records ***'
GO
INSERT INTO [dbo].[WorkoutProgram]
		([Duration], [SplitID])
	VALUES
		('8 Weeks', 1000000),
		('12 Weeks', 1000001)
GO

print '' print '*** Creating WorkoutProgram SplitID foreign key ***'
GO
ALTER TABLE [dbo].[WorkoutProgram]  WITH NOCHECK 
	ADD CONSTRAINT [FK_SplitID] FOREIGN KEY([SplitID])
	REFERENCES [dbo].[WorkoutSplit] ([SplitID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating Exercise MuscleGroupID foreign key ***'
GO
ALTER TABLE [dbo].[Exercise]  WITH NOCHECK 
	ADD CONSTRAINT [FK_MuscleGroupID] FOREIGN KEY([MuscleGroupID])
	REFERENCES [dbo].[MuscleGroup] ([MuscleGroupID])
	ON UPDATE CASCADE
GO

