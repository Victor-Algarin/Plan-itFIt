﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanItFitMVC.Models;
using PlanItFitMVC.Repositories;
using PlanItFitMVC.Repositories.Interfaces;

namespace PlanItFitMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExerciseController : ControllerBase
    {
        private readonly IExerciseRepository _exerciseRepo;

        public ExerciseController(IExerciseRepository exerciseRepo)
        {
            _exerciseRepo = exerciseRepo;
        }

        public async Task<ActionResult<List<Exercise>>> Index()
        {
            return await _exerciseRepo.GetExercises();
        }
    }
}