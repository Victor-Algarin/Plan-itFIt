﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlanItFitMVC.Models
{
    public class Exercise
    {
        public int ExerciseID { get; set; }
        public String ExerciseName { get; set; }
        public int MuscleGroupID { get; set; }
    }
}
