﻿using PlanItFitMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlanItFitMVC.Repositories.Interfaces
{
    public interface IExerciseRepository
    {
        Task<List<Exercise>> GetExercises();
    }
}
