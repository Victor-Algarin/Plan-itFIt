﻿using Microsoft.Extensions.Configuration;
using PlanItFitMVC.Models;
using PlanItFitMVC.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace PlanItFitMVC.Repositories
{
    public class ExerciseRepository : IExerciseRepository
    {
        private readonly IConfiguration _config;

        public ExerciseRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("DefaultConnection"));
            }
        }
        
        public async Task<List<Exercise>> GetExercises()
        {
            using (IDbConnection conn = Connection)
            {
                string sQuery = "SELECT * FROM Exercise";
                conn.Open();
                var result = await conn.QueryAsync<Exercise>(sQuery);
                return result.ToList();
            }
        }
    }
}
